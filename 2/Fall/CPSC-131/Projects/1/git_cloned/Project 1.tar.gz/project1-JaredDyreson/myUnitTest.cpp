// Written by Jared Dyreson
#include <iostream>
#include "GroceryInventory.h"
#include "GroceryItem.h"

using namespace std;
void myTests();
int main(int argc, char* argv[]) {
  myTests();
  return 0;
}

void myTests(){
  cout << "Running unit test..." << endl;
  GroceryItem item("Apple", 1000, 1.29, true);
  GroceryItem item2("Banana", 1000, 1.29, true);
  cout << "Two GroceryItem objects have been created" << endl;

  cout << item << endl;
  cout << item2 << endl;

  cout << "Creating an inventory from scratch" << endl;
  GroceryInventory invent;
  
  cout << "Adding the two GroceryItem objects to GroceryInventory object" << endl;
  invent.addEntry(item);
  invent.addEntry(item2);

  cout << "Determing if item one is in the inventory" << endl;
  if(invent.getEntry("Apple").getName() == "Empty"){
    cerr << "Item not found in the inventory" << endl;
  }
  else{
    cout << "Apple: "  << invent.getEntry(string("Apple")).getUnitPrice() << endl;
  }
  cout << "Creating a new inventory from a manifest using overloaded constructor" << endl;
  GroceryInventory inventoryTwo("shipment.txt");
  if(invent != inventoryTwo){
    cout << "The two inventories are not the same and this test passed" << endl;
  }
  cout << "Brownie points; creating a file from our inventory" << endl;
  invent.createFileFromInventory("exported");
  for(size_t i=0; i < invent.size(); i++){
    cout << invent[i] << endl;
  }
  inventoryTwo = invent;
  if(invent == inventoryTwo){
    cout << "assignment operator works" << endl;
  }
}
