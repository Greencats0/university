#include <iostream>
#include "GroceryInventory.hpp"

using namespace std;
void myTests();
int main(int argc, char* argv[]) {
  GroceryInventory invent;
  // GroceryItem item("Apple", 100, 10.00, true);
  // cout << item << endl;
  invent.createListFromFile("shipment.txt");
  GroceryInventory invent2 = invent;
  if(invent == invent2){
    cout << "YASSSSSSS" << endl;
  }
  GroceryItem item;
  item.setName("Chocolate");
  item.setQuantity(100);
  item.setTaxationState(true);
  item.setUnitPrice(1.00);
  invent.addEntry(item);
  invent.addEntry(GroceryItem("Apple", 10, 1.50, false));
  cout << invent << endl;
  // myTests();
  return 0;
}

void myTests(){
  GroceryItem item("Apple", 1000, 1.29, true);
  GroceryItem item2("Banana", 1000, 1.29, true);
  cout << item << endl;
  GroceryInventory invent;

  invent.addEntry(item);
  invent.addEntry(item2);
  if(invent.getEntry("Apple").getName() == "Empty"){
    cerr << "Item not found in the inventory" << endl;
  }
  else{
    cout << invent.getEntry(string("Apple")).getUnitPrice() << endl;
  }
  invent.createFileFromInventory("exported");
}
