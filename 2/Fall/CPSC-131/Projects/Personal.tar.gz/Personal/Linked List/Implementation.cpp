#include "Linked_List.hpp"
#include <iostream>

int main(int argc, char* argv[]){
  list<size_t> li;
  node<int> integer;
  node<std::string> stringNode;

  size_t i = 10, j = 100;
  li.createNode(i);
  li.insert_start(1);
  li.insert_end(j);
  li.display();
  std::cout << "\n";
  return 0;
}
