# Project 1
### CSUF CPSC 131, Fall 2018

Skeleton code provided by CPSC-131 Team
Modified by Jared Dyreson
This will compile under clang++ AND g++

# Note
For some inexplicable reason anytime I attempt to integrate the testAnswer and testAnswerEpsilon functions from the main.cpp provided, both clang++ and g++ complain of redefinition of classes. This can be seen in the attached image. I thought this would work itself out but still persists. My attached unit test does  not seem to be plagued by this issue.

![alt text]("Please look at me in the readme.png")

MUST EDIT WITH YOUR OWN NAME AND EMAIL IN THE SAME FORMAT

Group members:

- Ada Lovelace adalovelace@csu.fullerton.edu
- Charles Babbage charlesbab@csu.fullerton.edu
- Jared Dyreson jareddyreson@csu.fullerton.edu
