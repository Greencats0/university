#include <iostream>
#include "1.hpp" // all the vector stuff
#include <cassert>
using std::cout;
using std::endl;
// do not use namespace willy nilly
// written by Jared Dyreson
// original code written by William McCarthy

// testing out if it works

int main() {
  v_<size_t> v1;
  for(size_t i=0; i< v1.size(); i++){
    v1.push_back(i);
  }
  for(size_t i=0; i< v1.size(); i++){
    cout << v1[i] << endl;
  }
  v_<size_t> v2;
  if(v1 == v2){
    cout << "They are the same" << endl;
  }
  else{
    cout << "Not the same" << endl;
  }
  // v1 = v2;
  for(size_t i=0; i< v1.size(); i++){
    v1.pop_back();
  }
  for(size_t i=0; i< v1.size(); i++){
    cout << v1[i] << endl;
  }
  return 0;
}
