#include <stdio.h>

extern int adding(int a, int b);

int main() {
	printf("%d\n", adding(2, 3));
	return 0;
}
