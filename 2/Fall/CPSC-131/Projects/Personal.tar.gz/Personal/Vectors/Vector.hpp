// Written by Jared Dyreson
// Adapted from the work of William McCarthy
#include <iostream>
#include <cassert>
template <typename T>
class vector_{
  public:

    // copying function
    void copy(const vector_ &vector){
      // if the data is not cleared. We do not want a race condition. Never trust the USER!
      if(data_ != nullptr){
        // clear the array
        delete[] data_;
        // set the pointer to null so we can give it a new address
        data_ = nullptr;
      }
      // *this->[OBJECT], this wotks because in the case of VECTOR_ONE = VECTOR_2, VECTOR_ONE is the "*this" or current object
      // this makes more sense because without understanding that, it looks like random variables that have no source. Either way is correct, this way makes more sense
      *this->size_ = vector.size_();
      *this->length_ = vector.length_();
      std::copy(vector.begin(), vector.end(), *this->data_);
    }
    // CONSTRUCTORS

    // default constructor and we will  give it a size of zero because we just want it to fit with the other constructor that has the supplied size
    vector_() : vector_(){};
    // constructor when given a certain size
    vector_(size_t size_) : size_(size_), length_(0), data_(new T[size_]){};
  //class  (SIZE OF VECTOR) : var(size passed), var(default), var(contains dynamic array of values with a variable data type as big as the vector)
    // copy constructor
    vector_(const vector_& vector) : data_(nullptr) { copy(vector); }
    // deep delete
    ~vector_(){
      delete [] data_;
    }
//
    // DEFINE THE BOUNDS

    // begin and end so we can use std::copy and for(auto)
    T* begin() const { return data_; } // starting point of the array
    T* end() const { return (data_ + length_); }
    size_t length() const { return length_; }
    size_t size() const  { return size_; }


    // OPERATOR OVERLOADING
    friend std::ostream& operator<<(std::ostream& os, const vector_& vector){
      if(vector.length_ == 0){
        throw new std::invalid_argument("Vector is empty");
      }
      for(auto val: vector){
        std::cout << val << std::endl;
      }
      return os;
    }
    vector_& operator=(const vector_& vector){
      // please don't copy assign a = a :)
      if(this != &vector){
        copy(vector);
      }
      else{
        throw new std::invalid_argument("Cannot assign variable to itself");
      }
      return *this;
    }
    friend bool operator!=(const vector_& a, const vector_& b){
      if((a.length_ != b.length_) || (a.size_ != b.length_)){
        return false;
      }
      for(size_t i = 0; i < a.length_; i++){
        if(a.data_[i] != b.data_[i]){
          return false;
        }
      }
      return true;
    }


    // adding more elements in the array
    void push_back(T val){
      if(length_ == size_){
        resize(size_*2);
      }
      // this is a slower method
      data_[length_++] = val;
      // faster method would be in the form of linked list
      // Helps explain --> https://www.codementor.io/codementorteam/a-comprehensive-guide-to-implementation-of-singly-linked-list-using-c_plus_plus-ondlm5azr
      // For future reference  (copy current link into clipboard) --> https://stackoverflow.com/questions/9854044/firefox-extension-that-copies-html-link-to-current-web-page-to-clipboard-and-not
      length_++;
    }

    // delete element in the array
    void pop_back(){
      if(length_ < (size_/2)){
        resize(size_/2);
      }
      data_[length_-1] = T();
    }
    void resize(size_t newSize){
      T* newData = new T[newSize];
      std::copy(data_, data_+length_, newData);
      size_ = newSize;
      delete [] data_;
      data_ = newData;
    }

    // grab element from data array
    T  & operator[](size_t size){
      return data_[size];
    }
  private:
    // functions
  private:
    // variables and the order matters as the compiler will read left to right in the constructor and top to bottom in the private field
    // the size and length are unsigned int's
    size_t size_;
    size_t length_;
    // since we want the vector to store different data types, we will use a template to sub in the values
    T* data_;
};
