#include <fstream>
#include <sstream>
#include <list>

struct snode{
  snode() : snode("", "", 0){}
  snode(const std::string& lname , const std::string& fname, float salary, snode* next=nullptr) : lname_(lname), fname_(fname), salary_(salary), next_(next){}
  
  friend bool operator==(const snode& a, const snode&b){
    return ((a.lname_ == b.lname_) && (a.fname_ == b.fname_) && (a.salary_ == b.salary_));
  }
  std::string lname_;
  std::string fname_;
  float salary_;
  snode* next_;
};
