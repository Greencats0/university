#include "spootify.hpp"
#include <iostream>

int main() {
  playlist p;
  std::cout << p.size() << std::endl;
  return 0;
}
