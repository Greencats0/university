# Project 2
## CSUF CPSC 131, Fall 2018

MUST EDIT WITH YOUR OWN NAME AND EMAIL IN THE SAME FORMAT

Group members:
- Ada Lovelace adalovelace@csu.fullerton.edu
- Charles Babbage charlesbab@csu.fullerton.edu
- Jared Dyreson jareddyreson@csu.fullerton.edu

