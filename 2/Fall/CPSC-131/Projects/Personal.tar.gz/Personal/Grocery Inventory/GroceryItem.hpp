
#include <iostream>
#include <string>

class GroceryItem{
  public:
    GroceryItem();
    GroceryItem(const std::string&, const int&, const double&, const bool&);

    std::string getName() const;
    void setName(const std::string&);
    int getQuantity() const;
    void setQuantity(const int&);
    double getUnitPrice() const;
    void setUnitPrice(const double&);
    bool getTaxationState() const;
    void setTaxationState(const bool&);

    friend std::ostream& operator<<(std::ostream& os, const GroceryItem& item);
    friend bool operator==(const GroceryItem& a, const GroceryItem& b);
    friend bool operator!=(const GroceryItem& a, const GroceryItem& b);

  private:
    std::string name_;
    int quantity_;
    double unitPrice_;
    bool isTaxable_;
};

GroceryItem::GroceryItem(){}
GroceryItem::GroceryItem(const std::string& name, const int& quant, const double& tax, const bool& taxable){
  name_ = name;
  quantity_ = quant;
  unitPrice_ = tax;
  isTaxable_ = taxable;
}


std::string GroceryItem::getName() const{
  return name_;
}


void GroceryItem::setName(const std::string& name){
  name_ = name;
}


int GroceryItem::getQuantity() const {
  return quantity_;
}


void GroceryItem::setQuantity(const int &quantity){
  quantity_ =  quantity;
}


double GroceryItem::getUnitPrice() const {
  return unitPrice_;
}


void GroceryItem::setUnitPrice(const double &unit){
  unitPrice_ = unit;
}


bool GroceryItem::getTaxationState() const {
  return isTaxable_;
}


void GroceryItem::setTaxationState(const bool &state){
  isTaxable_ = state;
}

std::ostream& operator<<(std::ostream& os, const GroceryItem& item){
  os << "Item: " << item.getName() << "\n";
  os << "Amount: " << item.getQuantity() << "\n";
  os << "Unit Price: " << item.getUnitPrice() << "\n";
  os << "Taxable: " << item.getTaxationState() << "\n";
  return os;
}

// I'd love to make this into Turing notation but....
bool operator==(const GroceryItem& a, const GroceryItem& b){
  if((a.getName() != b.getName()) || (a.getQuantity() != b.getQuantity()) || (a.getUnitPrice() != b.getUnitPrice()) || (a.getTaxationState() != b.getTaxationState())){
    return false;
  }
  return true;
}

// love this short hand, makes a cleaner code base :)
bool operator!=(const GroceryItem& a, const GroceryItem& b){
  return !operator==(a, b);
}
