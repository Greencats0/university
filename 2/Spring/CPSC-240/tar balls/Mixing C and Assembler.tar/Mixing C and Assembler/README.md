# Link
- https://picoledelimao.github.io/blog/2016/02/27/mixing-assembly-and-c/

Main take away is that GCC is awesome and handles everything
