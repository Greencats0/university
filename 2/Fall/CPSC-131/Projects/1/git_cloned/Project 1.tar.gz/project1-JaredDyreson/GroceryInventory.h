#include "GroceryItem.h"
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>

class GroceryInventory{
  public:
    GroceryInventory();
    GroceryInventory operator=(const GroceryInventory& invent);
    GroceryInventory(std::string);
    // GroceryInventory(const GroceryInventory& invent);
    GroceryItem& getEntry(const std::string);
    void addEntry(const GroceryItem& item);
    void addEntry(const std::string&, const int&, const float&, const bool&);
    float getTaxRate() const;
    void setTaxRate(const float&);

    void createListFromFile(const std::string&);
    void createFileFromInventory(const std::string&);
    float calculateUnitRevenue() const;
    float calculateTaxRevenue() const;
    float calculateTotalRevenue() const;
    size_t size() const;

    GroceryItem& operator[](size_t);
    GroceryItem operator[](size_t) const;
    friend bool operator==(const GroceryInventory& a, const GroceryInventory& b);
    friend bool operator!=(const GroceryInventory& a, const GroceryInventory& b);
    friend std::ostream& operator<<(std::ostream& os, const GroceryInventory& invent);
    friend std::ofstream& operator>>(std::ifstream& is, const GroceryInventory& invent);
  private:
    std::vector<GroceryItem> inventory_;
    float taxRate_=0.075;
    size_t size_;
};


GroceryInventory::GroceryInventory() {}
// GroceryInventory::GroceryInventory(const GroceryInventory& invent){}


void GroceryInventory::addEntry(const GroceryItem& item){
  inventory_.push_back(item);
}

void GroceryInventory::addEntry(const std::string & n, const int &p,  const float &q, const bool &tf){
  GroceryItem item(n, p, q, tf);
  addEntry(item);
}

std::ostream& operator<<(std::ostream& os, const GroceryInventory& invent){
  for(size_t i = 0; i < invent.inventory_.size(); i++){
    os << invent[i] << "\n";
  }
  return os;
}

void GroceryInventory::createListFromFile(const std::string& filePath){
  std::string line, subline;
  std::ifstream source(filePath);
  if(source.is_open()){
    while(getline(source, line)){
      GroceryItem item;
      std::stringstream ss(line);
      std::string name;
      float tempfloat;
      int tempInt;
      bool tempBool;
      while(ss >> name >> tempInt >> tempfloat >> tempBool){
        item.setName(name);
        item.setQuantity(tempInt);
        item.setTaxable(tempBool);
        item.setUnitPrice(tempfloat);
        ss.clear();
      }
      this->addEntry(item);
    }
  }
  else{
    throw new std::invalid_argument("Could not open file, cowardly refusing");
  }
  source.close();
}

bool operator==(const GroceryInventory& a, const GroceryInventory& b){
  if(a.inventory_.size() != b.inventory_.size()){
    return false;
  }
  for(size_t i=0; i < a.inventory_.size(); i++){
    if(a[i] != b[i]){
      return false;
    }
  }
  return true;
}

bool operator!=(const GroceryInventory& a, const GroceryInventory& b){
  return !operator==(a, b);
}
GroceryInventory GroceryInventory::operator=(const GroceryInventory &invent){
  this->inventory_ = invent.inventory_ ;
  return *this;
}

GroceryItem& GroceryInventory::getEntry(std::string name){
  GroceryItem *item = new GroceryItem;
  item->setName("Empty");
  for(size_t i=0; i < inventory_.size(); i++){
    if(inventory_[i].getName() == name){
      return inventory_.at(i);
      break;
    }
  }
  return *item;
}

float GroceryInventory::calculateUnitRevenue() const{
  float sum = 0;
  for(size_t i = 0; i < inventory_.size(); i++){
    sum+=inventory_.at(i).getUnitPrice();
  }
  return sum;
}

float GroceryInventory::calculateTaxRevenue() const {
  return (calculateUnitRevenue() * taxRate_);
}

float GroceryInventory::calculateTotalRevenue() const{
  return (calculateUnitRevenue() + calculateTaxRevenue());
}

void GroceryInventory::setTaxRate(const float & rate){
  // we want the rate in the proper format
  // if(rate > 1){
  //   taxRate_ = (rate * .01);
  // }
  // else{
  //   taxRate_ = rate;
  // }
  taxRate_ = (rate * 0.01);
}

GroceryItem& GroceryInventory::operator[](size_t index){
  return inventory_.at(index);
}

GroceryItem GroceryInventory::operator[](size_t index) const{
  return inventory_.at(index);
}

void GroceryInventory::createFileFromInventory(const std::string &path){
  std::ofstream writing(path);
  if(writing.is_open()){
    for(size_t i=0; i < inventory_.size(); i++){
      writing << "Item: " << inventory_.at(i).getName() << "\n";
      writing << "Amount: " << inventory_.at(i).getQuantity() << "\n";
      writing << "Unit Price: " << inventory_.at(i).getUnitPrice() << "\n";
      writing << "Taxable: " << inventory_.at(i).isTaxable() << "\n";
      writing << "\n";
    }
    writing.close();
  }
  else{
    throw new std::invalid_argument("File exists currently, cowardly refusing to override");
  }
}

GroceryInventory::GroceryInventory(std::string manifest){
  createListFromFile(manifest);
}

size_t GroceryInventory::size() const {
  return inventory_.size();
}
