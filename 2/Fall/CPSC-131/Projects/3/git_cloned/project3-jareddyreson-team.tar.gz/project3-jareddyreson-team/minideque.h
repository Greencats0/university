//
//  minideque.h
//  minidequeproject
//  written by Jared Dyreson
//  What the hell is a deque -> https://stackoverflow.com/questions/6292332/what-really-is-a-deque-in-stl


#ifndef minideque_h
#define minideque_h

#include <vector>
#include <stack>
#include <algorithm>
#include <string>
#include <iostream>

template <typename T>
class minideque {
  private:
    std::vector<T> fronthalf_;
    std::vector<T> backhalf_;
  public:
    minideque() = default;                                   // do not change, C++ defaults are ok
    minideque(const minideque<T>& other) = default;          // rule of three
    minideque& operator=(const minideque<T>& other) = default;
    ~minideque() = default;

    size_t size() const;
    size_t fronthalfsize() const;
    size_t backhalfsize() const;
    bool empty()  const;

    void pop_front();
    void pop_back();

    void push_front(T v);
    void push_back(T v);

    T& front();
    T& back();
    const T& front() const;
    const T& back() const;
    const T& operator[](size_t index) const;  // TODO
    T& operator[](size_t index);

    void balanceDeque();
    void testDeque();
    void resize();
    friend std::ostream& operator<<(std::ostream& os, const minideque<T>& dq) {    // do not change
      if (dq.empty()) { return os << "minideque is empty"; }

      dq.printFronthalf(os);
      os << "| ";
      dq.printBackhalf(os);
      os << ", front:" << dq.front() << ", back:" << dq.back() << ", size:" << dq.size();
      return os;
    }

    void printFronthalf(std::ostream& os=std::cout) const {                    // do not change
      if (empty()) { std::cout << "fronthalf vector is empty"; }

      for (typename std::vector<T>::const_reverse_iterator crit = fronthalf_.crbegin();
           crit != fronthalf_.crend(); ++crit) {
        os << *crit << " ";
      }
    }

    void printBackhalf(std::ostream& os=std::cout) const {                     // do not change
      if (empty()) { os << "backhalf vector is empty"; }

      for (typename std::vector<T>::const_iterator cit = backhalf_.cbegin();
           cit != backhalf_.cend(); ++cit) {
        os << *cit << " ";
      }
    }
};


template <typename T>
size_t minideque<T>::fronthalfsize() const { return fronthalf_.size(); }
template <typename T>
size_t minideque<T>::backhalfsize() const { return backhalf_.size(); }
template <typename T>
size_t minideque<T>::size() const { return(fronthalfsize() + backhalfsize()); }
template <typename T>
bool minideque<T>::empty() const { return (fronthalfsize() == 0 && backhalfsize() == 0) ? 1 : 0; }

template <typename T>
T& minideque<T>::front(){
  // this function is correct
  if(!fronthalf_.empty()){ return fronthalf_.back(); }
  else if(!backhalf_.empty()){ return backhalf_.at(0); }
  throw new std::logic_error("out of bounds");
}

template <typename T>
T& minideque<T>::back(){
  // this function is correct
  auto b = backhalf_.rbegin(); // iterate through the vector in reverse
  return *(b);
}

template <typename T>
const T& minideque<T>::front() const{
  if(!fronthalf_.empty()){ return fronthalf_.back(); }
  else if(!backhalf_.empty()){ return backhalf_[0]; }
  throw new std::logic_error("out of bounds");
}

template <typename T>
const T& minideque<T>::back() const{
  auto b = backhalf_.rbegin();
  return *(b);
}
template <typename T>
void minideque<T>::push_front(T v){
  fronthalf_.push_back(v);
}

template <typename T>
// this only deals with the the backhalf_ vector, the function name is misleading
// should read out push_backhalf_
void minideque<T>::push_back(T v){
  // auto iterator = backhalf_.end();
  // backhalf_.insert(iterator, v);
  backhalf_.push_back(v);
}


template <typename T>
void minideque<T>::pop_front(){
  // pop the front element in the fronthalf_ vectors
  if(fronthalfsize() == backhalfsize()){
    fronthalf_.pop_back();
    backhalf_.pop_back();
    return;
  }
   if(fronthalf_.empty()){
     for(size_t i = 0; i < backhalfsize(); ++i){
       if((backhalfsize()+1)/2 && i !=0){ fronthalf_.push_back(backhalf_[backhalfsize() - i]); }
       backhalf_.pop_back();
     }
   }
   else if(backhalf_.empty()){
     for(size_t i = 0; i < fronthalfsize(); ++i){
       if((backhalfsize()+1)/2 && i !=0){ backhalf_.push_back(fronthalf_[fronthalfsize() - i]); }
       fronthalf_.pop_back();
     }
   }
   else { fronthalf_.pop_back(); }
}

template <typename T>
void minideque<T>::pop_back(){
  if(fronthalfsize() == backhalfsize()){
    fronthalf_.pop_back();
    backhalf_.pop_back();
  }
  if(backhalf_.empty()){
    for(int i = 0; i < fronthalfsize(); ++i){
      if((fronthalfsize()+1)/2 && i != 0) { backhalf_.push_back(fronthalf_[fronthalfsize() - i]); }
      fronthalf_.push_back();
    }
  }
  else if(fronthalf_.empty()){
    for(int i = 0; i < backhalfsize(); ++i){
      if((backhalfsize()+1)/2 && i != 0) { fronthalf_.push_back(fronthalf_[backhalfsize() -i]); }
      backhalf_.pop_back();
    }
  }

}

template <typename T>
T& minideque<T>::operator[](size_t index){
  if(index >= fronthalfsize()){
    auto begin = backhalf_.begin();
    begin+index;
    return *(begin);
  }
  return fronthalf_[index];
}
template <typename T>
const T& minideque<T>::operator[](size_t index) const{
  if(index >= fronthalfsize()){
    auto begin = backhalf_.begin();
    begin+index;
    return *(begin);
  }
  return fronthalf_[index];
}
#endif
