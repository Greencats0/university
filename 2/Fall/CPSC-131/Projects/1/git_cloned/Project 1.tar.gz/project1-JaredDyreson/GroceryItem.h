#pragma once
#include <iostream>
#include <string>

class GroceryItem{
  public:
    GroceryItem(){};
    GroceryItem(const std::string&, const int&, const float&, const bool&);


    std::string getName() const;
    void setName(const std::string&);
    int getQuantity() const;
    void setQuantity(const int&);
    float getUnitPrice() const;
    void setUnitPrice(const float&);
    bool isTaxable() const;
    void setTaxable(const bool&);

    friend std::ostream& operator<<(std::ostream& os, const GroceryItem& item);
    friend bool operator==(const GroceryItem& a, const GroceryItem& b);
    friend bool operator!=(const GroceryItem& a, const GroceryItem& b);

  private:
    std::string name_;
    int quantity_;
    float unitPrice_;
    bool isTaxable_;
};

GroceryItem::GroceryItem(const std::string& name, const int& quant, const float& tax, const bool& taxable){
  setName(name);
  setQuantity(quant);
  setUnitPrice(tax);
  setTaxable(taxable);
}
std::string GroceryItem::getName() const{
  return name_;
}


void GroceryItem::setName(const std::string& name){
  name_ = name;
}


int GroceryItem::getQuantity() const {
  return quantity_;
}


void GroceryItem::setQuantity(const int &quantity){
  quantity_ =  quantity;
}


float GroceryItem::getUnitPrice() const {
  return unitPrice_;
}


void GroceryItem::setUnitPrice(const float &unit){
  unitPrice_ = unit;
}


bool GroceryItem::isTaxable() const {
  return isTaxable_;
}


void GroceryItem::setTaxable(const bool &state){
  isTaxable_ = state;
}

std::ostream& operator<<(std::ostream& os, const GroceryItem& item){
  os << "Item: " << item.getName() << "\n";
  os << "Amount: " << item.getQuantity() << "\n";
  os << "Unit Price: " << item.getUnitPrice() << "\n";
  os << "Taxable: " << item.isTaxable() << "\n";
  return os;
}

// I'd love to make this into Turing notation but....
bool operator==(const GroceryItem& a, const GroceryItem& b){
  if((a.getName() != b.getName()) || (a.getQuantity() != b.getQuantity()) || (a.getUnitPrice() != b.getUnitPrice()) || (a.isTaxable() != b.isTaxable())){
    return false;
  }
  return true;
}

// love this short hand, makes a cleaner code base :)
bool operator!=(const GroceryItem& a, const GroceryItem& b){
  return !operator==(a, b);
}
