# Assignment 6

## D Flip Flop

![Example 1](assets/D\ Flip\ Flop\ Design.png){width=75%}

## D Latch

![Example 2](assets/D\ Latch.png){width=75%}

The D-Type Flip-flop changed state when it was rising clock edge. You can use a JK flip flop to make a T flip flop because they are essentially the same circuit design where a T flip flop has two inputs rather than one. According to the documentation provided by Fairchild, it is possible for one to make a 8 bit binary counter but if asked to on the spot, I personally cannot.
