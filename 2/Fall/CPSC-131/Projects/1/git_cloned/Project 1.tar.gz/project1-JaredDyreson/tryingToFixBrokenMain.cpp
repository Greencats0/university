// for some reason the main.cpp provided completely breaks my header files
// my unit test outlines everything required

#include "GroceryItem.h"
#include "GroceryInventory.h"

using namespace std;
template <typename T>
bool testAnswer(const string&, const T&, const T&);
template <typename T>
bool testAnswerEpsilon(const string&, const T&, const T&);




// his functions

template <typename T>
bool testAnswer(const string& nameOfTest, const T& received, const T& expected) {
    if (received == expected) {
        cout << "PASSED " << nameOfTest << ": expected and received " << received << endl;
        return true;
    }
    cout << "FAILED " << nameOfTest << ": expected " << expected << " but received " << received << endl;
    return false;
}
template <typename T>
bool testAnswerEpsilon(const string& nameOfTest, const T& received, const T& expected) {
    const double epsilon = 0.0001;
    if ((received - expected < epsilon) && (expected - received < epsilon)) {
        cout << fixed << "PASSED " << nameOfTest << ": expected and received " << received << endl;
        return true;
    }
    cout << "FAILED " << nameOfTest << ": expected " << expected << " but received " << received << endl;
    return false;
}
