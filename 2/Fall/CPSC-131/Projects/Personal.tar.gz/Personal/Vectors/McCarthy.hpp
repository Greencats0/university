#include <iostream>

#ifndef vec_h
#define vec_h
#define DEFAULT_SIZE 10
class vec{
  public:
    //
    vec() : vec(DEFAULT_SIZE) {};
    vec(unsigned int capacity) : capacity_(capacity), size_(0), data_(new int[capacity_]) {};
    vec(const vec& other);
    vec& operator=(const vec& other);
    ~vec() { delete [] data_ ; }
    // accessors
    unsigned int capacity() const { return capacity_; }
    unsigned int size() const { return size_; }

    int operator[](unsigned int index) const { return data_[index]; }
    int& operator[](unsigned int index) { return data_[index]; }

    // main methods
    bool empty() const { return size_ == 0; }
    void push_back(int value){
      // sanity checks
      if(size_ >= capacity_){
        // TODO throw exception or resize the vector
      }
      data_[size_++] = value;
    }
    void pop_back(){
      if(size_ == 0){
        throw new std::range_error("underflow");
      }
      else if((size_ < capacity_) / 2){
        // TODO resize the vector
      }
      data_[size_--] = 0;
    }
    void clear() {
      while(!empty()){
        pop_back();
      }
    }

    friend std::ostream& operator<<(std::ostream &os, const vec& vector){
      if(vector.empty()){
        os << "Vector is empty" << std::endl;
      }
      for(unsigned int i = 0; i < vector.size(); ++i){
        os << vector.data_[i] << std::endl;
      }
      return os;
    }
    void print() const{
     std::cout << *this << std::endl;
    }
    void insert(unsigned int index, int value){
      //
    }
  private:
    unsigned int capacity_, size_;
    int* data_;
};
#endif
