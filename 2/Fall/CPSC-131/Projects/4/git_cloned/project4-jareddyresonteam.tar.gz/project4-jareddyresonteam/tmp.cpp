#include <iostream>
#include <string>
#include <fstream>
#include <sstream>

void function(std::string& path){
  std::fstream stream(path);
  std::string line;
  std::string	name_;
	float price_;
	int quantity_;
	bool taxable_;
  if(!stream.is_open()){
    std::cerr << "cannot open" << std::endl;
    exit(1);
  }
  while(std::getline(stream, line)){
    std::stringstream s(line);
    while(s >> name_ >> price_ >> quantity_ >> taxable_){
      AddItem(name_, price_, quantity_ >> taxable_);
    }
  }
  stream.close();
}
