#include "2.hpp"
#include <iostream>

using namespace std;

int main(){
  v_<int> t(10);
  v_<int> t1(10);
  for(size_t i = 0; i < 10; i++){
    t.push_back(i);
    t1.push_back(i);
    cout << t << endl;
  }
  v_<int> t2(t);
  cout << "T@ VEC"  << t2 << endl;
  if(t == t1){
    cout << "push_back function is working" << endl;
  }
  cout << "Attempting to add another element to this vector....." << endl;
  t.push_back(11);
  cout << t  << endl;
  for(size_t i = 0; i < 10; i++){
    t.pop_back();
    cout << t << endl;
  }
}
