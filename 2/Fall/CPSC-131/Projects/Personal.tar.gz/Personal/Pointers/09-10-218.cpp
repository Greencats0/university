#include <iostream>

class pointer{
  public:
    pointer(size_t value);
    value_(value);
  private:
    size_t value_;
};
