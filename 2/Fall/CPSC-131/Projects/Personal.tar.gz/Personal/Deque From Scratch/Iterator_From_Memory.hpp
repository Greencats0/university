#include <iostream>
#include <vector>


template <typename T>

class Iterator {
  public:
    //  constructors and destructors
    Iterator() = default;
    Iterator(const std::vector<T>& vector, size_t index) : vect_(vector), index_(index){}
  private:
    const std::vector<T>& vect_;
    size_t index_;
};
