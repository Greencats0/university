// www.cplusplus.com/reference/deque/deque/a
