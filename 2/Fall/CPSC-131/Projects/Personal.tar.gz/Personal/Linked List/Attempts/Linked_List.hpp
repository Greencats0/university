// This article practically taught me how to do this

// Think of linked list much like definite integrals; they have a bound and nothing can be accessed before or after the defined bounds.

// https://www.codementor.io/codementorteam/a-comprehensive-guide-to-implementation-of-singly-linked-list-using-c_plus_plus-ondlm5azr

#include <iostream>

template <typename T> struct node;
template <typename T> class list;

template <typename T>
struct node{
  T value_;
  node* next_;
};

template <typename T>
class list{
  public:
    list();
    void createNode(T value);
    void display();
    void insert_start(T value);
    void insert_end(T value);
    void insert_position(size_t index, T value);
  private:
    node<T> *head_, *tail_;
};

template <typename T>
list<T>::list() {
  // since nothing preceeds the head or tail, we set them to be null by default
  head_ = nullptr;
  tail_ = nullptr;
}

template <typename T>
void list<T>::createNode(T value){
  // create a temporary node
  node<T> *tmp = new node<T>;
  // insert value provided from the function parameter into tmp.data_
  tmp->value_ = value;
  // set the next node in the array to NULL as we don't want to access arbitrary memory
  tmp->next_ = nullptr;
  // if the head of the node is null, i.e) nothing preceeds it
  if(head_ == nullptr){
    // make the head and tail be our temporary node
    head_ = tmp;
    tail_ = tmp;
    // clean up our temporary node
    // delete tmp;
    // tmp = nullptr;
  }
  else{ // if there is another node preceeding the current node
    // move tail one space to the right by assigning the pointer of previous tail to the temporary node
    tail_->next_ = tmp;
    // copy it's contents into tail
    tail_=tmp;
  }
}

template <typename T>
void list<T>::display(){
  // create a temporary node
  node<T> *temp = new node<T>;
  // make this temporary node the tail of the list; shared custody
  temp = head_;
  // while temporary node is not null
  while(temp != nullptr){
    // print list content
    std::cout << temp->value_ << "\t";
    // move the pointer one increment further, nullptr or otherwise
    temp=temp->next_;
  }
  // delete temp;
  // temp = nullptr;
}


template <typename T>
void list<T>::insert_start(T value){
  // create temporary node
  node<T> *tmp = new node<T>;
  // transfer the value passed into tmp.value
  tmp->value_ = value;
  // assign it to be the head of the node
  tmp->next_ = head_;
  head_ = tmp;
  // delete tmp;
  // tmp = nullptr;
}

template <typename T>
void list<T>::insert_end(T value){
  createNode(value);
}

template <typename T>
void list<T>::insert_position(size_t index, T value){
  node<T> *pre = new node<T>;
  node<T> *current = new node<T>;
  node<T> *temporary = new node<T>;
  current = head_;
  for(size_t i = 0; i < index; i++){
    pre = current;
    current = current->next_;
  }
  temporary->data_ = value;
  pre->next_ = temporary;
  temporary->next_ = current;
}
