# Functions for Dequeues

- front
  - const and non-const
- end
  - const and non-const
- resize
  - copy all attributes of old dequeue and put it into new dequeue but not the data, use copy function to do that
