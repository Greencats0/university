#include <iostream>
#include <algorithm>
#define MIN 10
template <typename T> class v_;
template <typename T> std::ostream& operator<<(std::ostream& os, const v_<T>& vector);
template <typename T> bool operator!=(const v_<T>& a, const v_<T>& b);
template <typename T> bool operator==(const v_<T>& a, const v_<T>& b);

template <typename T>
class v_{
  public:

    // creation and deletion of v_ class
    v_();
    v_(size_t size);
    v_ operator=(const v_& vector);
    ~v_();

    // gathering information

    size_t size() const;
    size_t length() const;

    T* begin() const;
    T* end() const;

    // functions

    void pop_back();
    void push_back(T val);

    friend std::ostream& operator<< <>(std::ostream& os, const v_<T>& vector);
    friend bool operator!= <>(const v_<T>& a, const v_<T>& b);
    friend bool operator== <>(const v_<T>& a, const v_<T>& b);

    T operator[](size_t index) const; // RO
    T& operator[](size_t index); //RW

  private:
    size_t size_, length_;
    T* data_;
  private:
    void copy(const v_& vector);
    void resize(size_t newSize);
};

// default constructor
template <typename T>
v_<T>::v_() : size_(MIN), length_(0), data_(new T[size_]){};
// given size
template <typename T>
v_<T>::v_(size_t size) : size_(size), length_(0), data_(new T[size_]) {};

template <typename T>
v_<T> v_<T>::operator=(const v_<T>& vector){
  if(*this != vector){
    std::cout << "copying" << std::endl;
    copy(vector);
  }
  // std::cout << "did not copy" << std::endl;
  return *this;
}

template <typename T>
v_<T>::~v_(){
  delete [] data_;
}

template <typename T>
size_t v_<T>::size() const{
  return size_;
}

template <typename T>
size_t v_<T>::length() const {
  return length_;
}
// template <typename T> T* vector_<T>::begin() const { return data_; }
template <typename T>
T* v_<T>::begin() const{
  return data_;
}


template <typename T>
T* v_<T>::end() const{
  return (data_ + length_ );
}

template <typename T>
void v_<T>::pop_back() {
  if(length_ == 0){
    throw new std::range_error("underflow");
  }
  data_[length_--] = 0;
}

template <typename T>
void v_<T>::push_back(T val){
  if(length_ >= size_){
    // TODO resize or throw execption
    std::cerr << "need to resize" << std::endl;
  }
  data_[length_++] = val;
}

template <typename T>
bool operator!=(const v_<T>& a, const v_<T>& b){
  if((a.length_ != b.length_) || (a.size_ != b.size_)){
    return true;
  }
  for(size_t i = 0; i < a.size_; i++){
    if(a.data_[i] != b.data_[i]){
      return true;
    }
  }
  return false;
}
template <typename T>
bool operator==(const v_<T>& a, const v_<T>& b){
  return !(a != b);
}
template <typename T>
void v_<T>::copy(const v_& vector){
  if (data_ != nullptr) {
    std::cout << "deleted data when copying" << std::endl;
    delete [] data_;
  }
  if(*this != vector){
    // copy
    std::cout << "both are not the same so i am copying" << std::endl;
    size_ = vector.size_;
    length_ = vector.length_;
    data_ = new T[size_];
    for(size_t i = 0; i < size_; i++){
      data_[length_++] = vector[i];
    }
    //std::copy(vector.begin(), vector.end(), begin());
  }
  else{
    throw new std::invalid_argument("invalid assignemnt");
  }

}
// RO
template <typename T>
T v_<T>::operator[](size_t index) const{
  return data_[index];
}

//RW
template <typename T>
T& v_<T>::operator[](size_t index){
  return data_[index];
}
