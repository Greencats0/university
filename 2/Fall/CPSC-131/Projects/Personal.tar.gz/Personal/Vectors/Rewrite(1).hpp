// Attempted by Jared Dyreson
// Original Code Referenced written by  William McCarthy


#include <iostream>
#include <cassert>
using std::cout;
using std::endl;

template <typename T>

class vector_{
  public:
    // default constructor. Since we can catenate the default constructor and the constructor with a given size, we can just do one declaration
    vector_ (size_t size=0) : size_(size), length_(0), data_(new T[size_]){};
    // copy constructor
    vector_(const vector_<T>& vector);

    // destructor
    ~vector_();

    size_t size() const;
    size_t length() const;
    //T* begin() const; // starting point of the array
    T* end() const { return (*this->data_ + *this->length_); } // ending point of the array

    // operator overloading
    vector_& operator=(const vector_<T>& other);
    friend bool operator== <>(const vector_<T>& a, const vector_<T>& b);

  private:
    size_t size_, length_;
    T* data_;
  private:
    void copyDataContent(const vector_& vector){
      *this->size_ = vector.size_;
      *this->length_ = vector.length_;
      delete [] vector.data_;
      vector.data_ = nullptr;
      std::copy(*this->data_, vector.data_, vector.begin());
    }
};

template <typename T> size_t vector_<T>::size() const{ return size_; }

// deep delete
template <typename T>
vector_<T>::~vector_(){
  delete [] data_;
};

// copy constructor
template <typename T>
vector_<T>::vector_(const vector_<T>& vector) : data_(nullptr){
  copyDataContent(vector);
}
// OVERLOADING OPERATOR

// assignment
template <typename T>
vector_<T>& vector_<T>::operator=(const vector_<T> &other){
  {
    if(this != other){
      copyDataContent(other);
    }
    else{
      throw new std::invalid_argument("cannot set vector equal to itself");
    }
    return *this;
  }
}

// equality
template <typename T>
bool operator==(const vector_<T>& a, const vector_<T>& b){
  if((a.size_ != b.size_) || (a.length_ != b.length_) || !(std::is_same<T, T>::value)){
    return false;
  }
  for(size_t i = 0; i < a.length_; i++){
    if(a.data_[i] != b.data_[i]){
      return false;
    }
  }
  return true;
}
// template <typename T>
// vector_<T>::begin(){
//   return *this->data_;
// }
