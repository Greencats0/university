#include <iostream>
#define MIN_SIZE 10
// forward delcaration

template <typename T> class v_;
template <typename T> bool operator==(const v_<T>&a, const v_<T>& b);
template <typename T> bool operator!=(const v_<T>&a, const v_<T>& b);
template <typename T> std::ostream& operator<<(std::ostream& os, const v_<T>& a);


template <typename T>
class v_{
  public:
    // constructors
    v_();
    v_(size_t size);
    v_ operator=(const v_& vector);
    v_(const v_& vector);
    ~v_();

    T* begin() const;
    T* end() const;

    size_t size() const;
    size_t length() const;


    friend bool operator== <>(const v_<T>&a, const v_<T>& b);
    friend bool operator!= <>(const v_<T>&a, const v_<T>& b);
    friend std::ostream& operator<< <>(std::ostream& os, const v_<T>& a);

    T operator[](size_t i) const;
    T& operator[](size_t i);

    void pop_back();
    void push_back(T val);

  private:
    size_t size_, length_;
    T* data_;
  private:
    // functions
    void copy(const v_& vector);
    void resize(size_t size);
};


template <typename T>
v_<T>::v_()  : size_(MIN_SIZE), length_(0), data_(new T[MIN_SIZE]){};

template <typename T>
v_<T>::v_(size_t size) : size_(size), length_(0), data_(new T[size_]) {} ;

template <typename T>
v_<T> v_<T>::operator=(const v_<T>& vector){
  // do some copy constructor thingy
  copy(vector);
}

template <typename T>
v_<T>::~v_(){
  delete [] data_;
  data_ = nullptr;
}
template <typename T>
v_<T>::v_(const v_<T>& vector){
  copy(vector);
}

template <typename T>
void v_<T>::copy(const v_<T> &vector){
  size_ = vector.size_;
  length_ = vector.length_;
  if(data_ != nullptr){
    delete [] data_;
    data_ = nullptr;
  }
  data_ = new T[size_];
  std::copy(vector.data_, (vector.data_ + vector.length_), data_);
}

template <typename T>
bool operator==(const v_<T>&a, const v_<T>& b){
  if((a.length_ != b.length_) || (a.size_ != b.size_)){
    return false;
  }
  for(size_t i = 0; i < a.size_; i++){
    if(a.data_[i] != b.data_[i]){
      return false;
    }
  }
  return true;
}

template <typename T>
bool operator!=(const v_<T>&a, const v_<T>&b){
  return !operator==(a, b);
}

template <typename T>
std::ostream& operator<<(std::ostream& os, const v_<T>& a){
  // if(a.length_ == 0){
  //   return os << "v_<T> is empty" << std::endl;
  // }
  for(auto val:a){
    os << val << " ";
  }
  return os;
}

template <typename T>
size_t v_<T>::size() const{
  return size_;
}

template <typename T>
size_t v_<T>::length() const{
  return length_;
}

template <typename T>
T* v_<T>::begin() const{
  return data_;
}

template <typename T>
T* v_<T>::end() const{
  return (data_ + length_);
}

template <typename T>
void v_<T>::pop_back(){
  if(length_ == 0){
    std::range_error("underflow");
  }
  // else if() <----- try to resize the array if necessary
  data_[length_--] = T(); // why the heck does it not delete this memory???????????????????????
  // std::cout << T() << std::endl;
}

template <typename T>
void v_<T>::push_back(T val){
  if(length_ >= size_){
    resize(2 * size_);
    // std::range_error("overflow");
  }
  data_[length_++] = val;
}

template <typename T>
T& v_<T>::operator[](size_t i){
  return data_[i];
}

template <typename T>
void v_<T>::resize(size_t size){
  if(length_ > size){
    throw new std::range_error("cannot fit");
  }
  T* newData = new T[size];
  std::copy(data_, (newData + size), newData);
  size_ = size;
  delete [] data_;
  data_ = newData;
}
