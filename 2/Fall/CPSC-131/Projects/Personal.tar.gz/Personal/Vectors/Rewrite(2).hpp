#include <iostream>
using std::cout;
using std::endl;
using std::ostream;


// forward delcaration
template <typename T> class vector_;
template <typename T> vector_<T>& operator<<(ostream &os, const vector_<T>& vector);
template <typename T> bool operator!=(const vector_<T>& a, const vector_<T>& b);
template <typename T> bool operator==(const vector_<T>& a, const vector_<T>& b);

// writing the class structure
template <typename T>
class vector_{
  public:
    // functions that are allowed to anyone


    // constructors

    // default
    vector_();

    // given size / default since we pass in a  default size
    vector_(size_t size=0);

    // given vector as input

    vector_& operator=(const vector_& other);

    // destructor
    ~vector_();

    // characteristics of vector_

    size_t size() const;
    size_t length() const;

    T* begin() const;
    T* end() const;

    T front() const; // RO (Telling the compiler that we will never ever change the result)
    T* front(); // Rw (we are able to edit pointer)

    T back() const; // RO (Telling the compiler that we will never ever change the result)
    T* end(); // Rw (we are able to edit pointer)

    // establishing operators

    friend vector_<T>& operator<< <>(ostream &os, const vector_<T>& vector); // empty angle brackets tell the compiler how much space to allocate for this function? All I know is that it needs to be here sooooooooo yeah
    friend bool operator== <>(const vector_<T>& a, const vector_<T>& b);
    friend bool operator!= <>(const vector_<T>& a, const vector_<T>& b);

    T operator[](size_t i) const; // RO
    T& operator[](size_t i); // RW

    // functionality

    void push_back(T val);
    void pop_back();

  private:
    // characteristics of vector_
    size_t size_, length_;
    T* data_;
  private:
    // functions
    void copyDataContent(const vector_<T>& vector);
    void resize(size_t size);
};

// consructor

template <typename T>
vector_<T>::vector_(size_t size) : size_(size), length_(0), data_(new T[size_]) {}
// vector_<T>::vector_(size_t size)
// : size_(size), length_(0), data_(new T[size_]) {}
// destructor

template <typename T>
vector_<T>::~vector_(){
  delete [] data_;
}

// is this size_?
template <typename T>
size_t vector_<T>::size() const{
  return size_;
}

// is this length_

template <typename T>
size_t vector_<T>::length() const{
  return length_;
}

template <typename T>
T* vector_<T>::begin() const{
}

template <typename T>
vector_<T>& vector_<T>::operator=(const vector_<T>& other) {
  if(*this!=other){
    copyDataContent(other);
    cout << "this (length): " << *this->length_ << endl;
    cout << "this (size): " << *this->size_ << endl;
    cout << "other (length): " << other.length_ << endl;
    cout << "other (size): " << other.size_<< endl;
  }
}
// speak it from the rooftops
template <typename T> std::ostream& operator<<(ostream &os, const vector_<T>& vectr){
  for(auto val : vectr){
    cout << val << " ";
  }
  return os;
}

// checking for vector_ equalitity. Vector_ lives matter!!!!

template <typename T>
bool operator==(const vector_<T>& a, const vector_<T>& b){
  if((a.length() != b.length()) || (a.size() != b.size())){
    return false;
  }
  for(size_t i=0; i < a.size(); ++i){
    if(a.data_[i] != b.data_[i]){
      return false;
    }
  }
  return true;
}

// not equal, oh nooooooooo
template <typename T>
bool operator!=(const vector_<T>& a, const vector_<T>& b){
  return !(a == b);
}

// RO
template <typename T>
T vector_<T>::operator[](size_t i) const{
  return data_[i];
}

// RW
template <typename T>
T& vector_<T>::operator[](size_t i){
  return data_[i];
}


template <typename T>
void vector_<T>::push_back(T val){
  if(length_>= size_){
    std::cerr << "Resize needed" << endl;
  }
  data_[length_++] = val;
}

template <typename T>
void vector_<T>::pop_back(){
  if(length_ == 0){
    throw new std::invalid_argument("Buffer underflow");
  }
  // currently broken?
  data_[length_--] = T();
}

template <typename T>
void vector_<T>::copyDataContent(const vector_<T>& vector){
  if(*this != vector){
    delete [] data_;
    data_ = nullptr;
    *this->length_ = length_;
    *this->size_ = size_;
    // std::copy(*this->data, data_, );
  }
}
