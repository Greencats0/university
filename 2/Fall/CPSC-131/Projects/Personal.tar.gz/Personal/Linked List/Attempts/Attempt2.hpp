#include <iostream>
#include <string>

template <typename T>

struct node{
  T data_;
  node* next_;
};

template <typename T>
class slist{
  public:
    slist() : head_(nullptr), tail_(nullptr), size_(0){} // constructor
    // some fancy constructor
    slist(const std::initializer_list<T>& list){
      for(auto element : list){
        // push back something into the list
      }
    }

    // functionality
    void printList();
    void createNode(T value); // allows us to create a new node
    void push_back(T value);
    void insert_start(T value);
    void insert_position(size_t index, T value);
    void pop_back();
    void pop_front();
    void erase();

    // checkers for program sanity
    void check_nullptr(node<T>* node);
    void check_for_underflow();
    void check_for_overflow(size_t s);
    bool empty();


    // getters
    size_t size();




    ~slist(); // destructor
  private:
    node<T>* head_, *tail_;
    size_t size_;
};

template <typename T>
slist<T>::~slist(){}


template <typename T>
void slist<T>::createNode(T value){
  // create temporary node
  node<T> *tmp = new node<T>;
  // assgin the node to have the value of parameter
  tmp->data_ = value;
  // set the next pointer to null
  tmp->next_ = nullptr;
  // if the head is null (if the list is empty)
  if(head_ == nullptr){
    head_ = tmp;
    tail_ = tmp;
  }
  // if the list is not empty
  else{
    // move the next pointer of tail to be tmp
    tail_->next_ = tmp;
    // set the tmp to be the tail as it is the last element
    tmp = tail_;
  }
  ++size_;
}

template <typename T>
void slist<T>::push_back(T value){
  node<T> *tmp = new node<T>;
  tmp->next_ = tail_;
  tmp = tail_;
}
template <typename T>
void slist<T>::printList(){
  // create a temporary node
  node<T> *temp = new node<T>;
  // make this temporary node the tail of the list; shared custody
  temp = head_;
  // while temporary node is not
  while(temp != nullptr){
    // print list content
    std::cout << temp->data_ << "\t";
    // move the pointer one increment further, nullptr or otherwise
    temp=temp->next_;
  }
  std::cout << std::endl;
}

template <typename T>
void slist<T>::insert_start(T value){
  node<T> *tmp = new node<T>;
  tmp->data_ = value;
  tmp->next_ = head_;
  head_ = tmp;
  ++size_;
}

template <typename T>
void slist<T>::insert_position(size_t index, T value){
  check_for_overflow(index);
  node<T> *previous = new node<T>;
  node<T> *current = new node<T>;
  node<T> *tmp = new node<T>;
  current = head_;
  for(size_t i = 0; i < index; ++i){
    previous = current;
    current = current->next_;
  }
  tmp->data_ = value;
  previous->next_ = tmp;
  tmp->next_ = current;
  ++size_;
}

template <typename T>
void slist<T>::pop_back(){
  if(empty()){
    throw new std::invalid_argument("underflow");
  }
  node<T> *previous = new node<T>;
  node<T> *current = new node<T>;
  current = head_;
  while(current->next_ != nullptr){
    previous = current;
    current = current->next_;
  }
  tail_ = previous;
  previous->next_ = nullptr;
  --size_;
  delete current;
}

template <typename T>
void slist<T>::pop_front(){
  node<T>* tmp =  new node<T>;
  tmp = head_;
  head_ = head_->next_;
  delete tmp;
  size_--;
}
template <typename T>
void slist<T>::erase(){while(!empty()){ pop_front(); }}

template <typename T>
bool slist<T>::empty() { return (size_ == 0); }

template <typename T>
void slist<T>::check_nullptr(node<T>* node){ if(node == nullptr){ throw new std::invalid_argument("nullptr error"); } }
template <typename T>

void slist<T>::check_for_overflow(size_t s) { if(size_ < s){ throw new std::invalid_argument("buffer overflow"); } }

template <typename T>
void slist<T>::check_for_underflow() { if (empty()) { throw new std::invalid_argument("underflow"); }}

template <typename T>
size_t slist<T>::size() { return size_; }
