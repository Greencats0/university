#include <iostream>
#include "Iterator_From_Memory.hpp"

int main() {
  Iterator<int> it;
  return 0;
}
