#include <iostream>
#include <set>
#include <algorithm>
#include <fstream>
#include <string>
#include <vector>


class album{
public:
  album(std::string n, std::string a, std::vector<std::string> m) : name_(n), artist_(a), manifest(m){}
  std::string name() { return name_; }
  void name(std::string n){ name_ = n; }
  std::string artist() { return artist_; }
  void artist(std::string a) { artist_ = a; }
private:
  std::string name_, artist_;
  std::vector<std::string> manifest;
};

template <typename K, typename V>
struct pair{
  K key_;
  V value_;
  pair(K key, V value): key_(key), value_(value){}
  pair() : key_(nullptr), value_(nullptr){}
  friend std::ostream & operator << (std::ostream &out, const pair &p){
    out << "Key: " << p.key_ << std::endl;
    out << "Value: " << p.value_ << std::endl;
    return out;
  }
};

class playlist{
  public:
    // playlist(artistSongPair p) {
    //   pairs.insert(p);
    // }
    size_t size() { return pairs.size(); }
    void add(pair<std::string, std::string>& p){

      // pairs.insert(p);
    }
  private:
    // std::set<album> albums_;
    // std::set<std::string> artists_;
    std::set<pair<std::string, std::string>> pairs;
};



// class spootify{
//
// };
