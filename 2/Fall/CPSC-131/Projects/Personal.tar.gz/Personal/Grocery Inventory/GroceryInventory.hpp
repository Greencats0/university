#include "GroceryItem.hpp"
#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>

class GroceryInventory{
  public:
    GroceryInventory();
    GroceryInventory operator=(const GroceryInventory& invent);
    GroceryItem& getEntry(const std::string);
    void addEntry(const GroceryItem& item);
    double getTaxRate() const;
    void setTaxRate(const double&);

    void createListFromFile(const std::string&);
    void createFileFromInventory(const std::string&);
    double calculateUnitRevenue() const;
    double calculateTaxRevenue() const;
    double calculateTotalRevenue() const;

    GroceryItem& operator[](size_t);
    GroceryItem operator[](size_t) const;
    friend bool operator==(const GroceryInventory& a, const GroceryInventory& b);
    friend bool operator!=(const GroceryInventory& a, const GroceryInventory& b);
    friend std::ostream& operator<<(std::ostream& os, const GroceryInventory& invent);
  private:
    std::vector<GroceryItem> inventory_;
    double taxRate_=0.075;
};


GroceryInventory::GroceryInventory() {}

void GroceryInventory::addEntry(const GroceryItem& item){
  inventory_.push_back(item);
}

std::ostream& operator<<(std::ostream& os, const GroceryInventory& invent){
  for(size_t i = 0; i < invent.inventory_.size(); i++){
    os << invent[i] << "\n";
  }
  return os;
}

void GroceryInventory::createListFromFile(const std::string& filePath){
  std::string line, subline;
  std::ifstream source(filePath);
  if(source.is_open()){
    while(getline(source, line)){
      GroceryItem item;
      std::stringstream ss(line);
      std::string name;
      double tempDouble;
      int tempInt;
      bool tempBool;
      while(ss >> name >> tempInt >> tempDouble >> tempBool){
        item.setName(name);
        item.setQuantity(tempInt);
        item.setTaxationState(tempBool);
        item.setUnitPrice(tempDouble);
        ss.clear();
      }
      this->addEntry(item);
    }
  }
  else{
    throw new std::invalid_argument("Could not open file, cowardly refusing");
  }
  source.close();
}

bool operator==(const GroceryInventory& a, const GroceryInventory& b){
  if(a.inventory_.size() != b.inventory_.size()){
    return false;
  }
  for(size_t i=0; i < a.inventory_.size(); i++){
    if(a[i] != b[i]){
      return false;
    }
  }
  return true;
}

bool operator!=(const GroceryInventory& a, const GroceryInventory& b){
  return !operator==(a, b);
}
GroceryInventory GroceryInventory::operator=(const GroceryInventory &invent){
  this->inventory_ = invent.inventory_ ;
  return *this;
}

GroceryItem& GroceryInventory::getEntry(std::string name){
  GroceryItem *item = new GroceryItem;
  item->setName("Empty");
  for(size_t i=0; i < inventory_.size(); i++){
    if(inventory_[i].getName() == name){
      return inventory_.at(i);
      break;
    }
  }
  return *item;
}

double GroceryInventory::calculateUnitRevenue() const{
  double sum = 0;
  for(size_t i = 0; i < inventory_.size(); i++){
    sum+=inventory_.at(i).getUnitPrice();
  }
  return sum;
}

double GroceryInventory::calculateTaxRevenue() const {
  return (calculateUnitRevenue() * taxRate_);
}

double GroceryInventory::calculateTotalRevenue() const{
  return (calculateUnitRevenue() + calculateTaxRevenue());
}

void GroceryInventory::setTaxRate(const double & rate){
  // we want the rate in the proper format
  if(rate > 1){
    taxRate_ = (rate * .01);
  }
  else{
    taxRate_ = rate;
  }
}

GroceryItem& GroceryInventory::operator[](size_t index){
  return inventory_.at(index);
}

GroceryItem GroceryInventory::operator[](size_t index) const{
  return inventory_.at(index);
}

void GroceryInventory::createFileFromInventory(const std::string &path){
  std::ofstream writing(path);
  if(writing.is_open()){
    for(size_t i=0; i < inventory_.size(); i++){
      writing << "Item: " << inventory_.at(i).getName() << "\n";
      writing << "Amount: " << inventory_.at(i).getQuantity() << "\n";
      writing << "Unit Price: " << inventory_.at(i).getUnitPrice() << "\n";
      writing << "Taxable: " << inventory_.at(i).getTaxationState() << "\n";
      writing << "\n";
    }
    writing.close();
  }
  else{
    throw new std::invalid_argument("File exists currently, cowardly refusing to override");
  }
}
