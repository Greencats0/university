#include "Attempt2.hpp"
#include <iostream>
int main() {
  slist<int> li;
  li.createNode(10);
  li.createNode(100);
  li.createNode(1000);
  li.insert_start(5);
  li.insert_position(3, 25);
  std::cout << li.size() << std::endl;
  li.printList();
  li.pop_back();
  std::cout << li.size() << std::endl;
  li.printList();
  li.erase();
  li.printList();
  return 0;
}
