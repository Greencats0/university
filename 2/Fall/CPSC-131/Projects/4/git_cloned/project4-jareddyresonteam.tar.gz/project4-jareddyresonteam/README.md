# Project 4 Complete
Jared Dyreson jareddyreson@csu.fullerton.edu
Gaberiel Ball gabeball@csu.fullerton.edu

# NOTE
Compiled under clang++-6.0 and also compliant with clang++ version 3.8.0-2ubuntu4
